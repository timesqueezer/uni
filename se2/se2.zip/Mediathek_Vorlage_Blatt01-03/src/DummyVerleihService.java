import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Diese Klasse implementiert das Interface VerleihService. Es handelt sich
 * lediglich um eine Dummy-Implementation, um die GUI zu testen.
 * 
 * @author GUI-Team
 * @version SoSe 2017
 */
class DummyVerleihService extends AbstractObservableService
        implements VerleihService
{
    // Generator für Zufallszahlen und zufällige boolsche Werte
    private static final Random RANDOM = new Random();

    private static final CD MEDIUM = new CD("Titel", "Kommentar", "Interpret",
            70);
    private static final Kundennummer KUNDENNUMMER = new Kundennummer(123456);
    private static final Kunde ENTLEIHER = new Kunde(KUNDENNUMMER, "Vorname",
            "Nachname");
    private static final Verleihkarte VERLEIHKARTE = new Verleihkarte(ENTLEIHER,
            MEDIUM, Datum.heute());

    /**
     * Erstellt einen Kundenstamm, einen Medienbestand und eine Liste für die Verleihkarten.
     * 
     * @param kundenstamm Erzeugt einen neuen Kundenstamm
     * @param medienbestand Erzeugt einen neuen Medienbestand
     * @param initialBestand Eine neue Liste an für Verleihkarten
     */
    public DummyVerleihService(KundenstammService kundenstamm,
            MedienbestandService medienbestand,
            List<Verleihkarte> initialBestand)
    {
    }
    /**
     * Gibt an welche Medien ein bestimmter Kunde bisher ausgeliehen hat und speichert dieses in eine Liste.
     * Gibt das konstant erstellte MEDIUM anstatt echter Daten zurück.
     * 
     * @param kunde Der Kunde der das Medium ausgeliehen hat
     * 
     * @return Die Liste mit den ausgeliehenen Medien
     */
    @Override
    public List<Medium> getAusgelieheneMedienFuer(Kunde kunde)
    {
        List<Medium> ergebnisListe = new ArrayList<Medium>();
        ergebnisListe.add(MEDIUM);
        return ergebnisListe;
    }
    /**
     * Gibt an welcher Kunde ein bestimmtes Medium ausgeliehen hat.
     * Hier wird immer ENTLEIHER unabhängig vom medium zurückgegeben.
     * 
     * @param medium Das Medium welches ausgeliehen wurde 
     * 
     * @return Der Kunde 
     */
    @Override
    public Kunde getEntleiherFuer(Medium medium)
    {
        return ENTLEIHER;
    }
    /**
     * Gibt die Verleihkarte für das besagte Medium an.
     * Gibt die konstante VERLEIHKARTE unabhängig vom medium zurück.
     * 
     * @param medium Das Medium welches ausgeliehen wurde 
     * 
     * @return Die Verleihkarte 
     */
    @Override
    public Verleihkarte getVerleihkarteFuer(Medium medium)
    {
        return VERLEIHKARTE;
    }
    /**
     * Gibt alle Verleihkarten in einer Liste an
     * Gibt immer eine Liste mit der Konstanten VERLEIHKARTE zurück.
     * 
     * @return Die Liste mit den Verleihkarten 
     */
    @Override
    public List<Verleihkarte> getVerleihkarten()
    {
        List<Verleihkarte> ergebnisListe = new ArrayList<Verleihkarte>();
        ergebnisListe.add(VERLEIHKARTE);
        return ergebnisListe;
    }

    /**
     * Gibt zufällig ausgewählt entweder true oder false zurück.
     * 
     * @param medium
     * 
     * @return ob das Medium ausgeliehen ist
     */
    @Override
    public boolean istVerliehen(Medium medium)
    {
        return RANDOM.nextBoolean();
    }

    /**
     * Hat keine Funktionalität
     */
    @Override
    public void nimmZurueck(List<Medium> medien, Datum rueckgabeDatum)
    {
    }

    /**
     * Gibt zufällig ausgewählt entweder true oder false zurück.
     * 
     * @param medium
     * 
     * @return ob das alle Medien nicht verliehen ist
     */
    @Override
    public boolean sindAlleNichtVerliehen(List<Medium> medien)
    {
        return RANDOM.nextBoolean();
    }

    /**
     * Gibt zufällig ausgewählt entweder true oder false zurück.
     * 
     * @param medium
     * 
     * @return ob alle Medien verliehen sind.
     */
    @Override
    public boolean sindAlleVerliehen(List<Medium> medien)
    {
        return RANDOM.nextBoolean();
    }

    /**
     * Leerer Methodenrumpf ohne Funktionalität.
     */
    @Override
    public void verleiheAn(Kunde kunde, List<Medium> medien, Datum ausleihDatum)
    {
    }

    /**
     * kunde wird immer mit der Konstanten ENTLEIHER verglichen.
     */
    @Override
    public boolean kundeImBestand(Kunde kunde)
    {
        return ENTLEIHER.equals(kunde);
    }

    /**
     * vergleicht medium immer mit der Konstanten medium.
     */
    @Override
    public boolean mediumImBestand(Medium medium)
    {
        return MEDIUM.equals(medium);
    }

    /**
     * Ist wie vom Interface beschrieben implementiert.
     * Gibt zurück, ob die übergebene Liste der Medien im Bestand sind.
     */
    @Override
    public boolean medienImBestand(List<Medium> medien)
    {
        boolean result = true;
        for (Medium medium : medien)
        {
            if (!mediumImBestand(medium))
            {
                result = false;
                break;
            }
        }
        return result;
    }

    /**
     * Liefert eine Liste mit der Konstanten VERLEIHKARTE unabhängig von kunde zurück.
     */
    @Override
    public List<Verleihkarte> getVerleihkartenFuer(Kunde kunde)
    {
        List<Verleihkarte> result = new ArrayList<Verleihkarte>();
        result.add(VERLEIHKARTE);
        return result;
    }

    /**
     * Gibt in jedem Fall false zurück.
     */
    @Override
    public boolean istVerleihenMoeglich(Kunde kunde, List<Medium> medien)
    {
        return false;
    }
}
