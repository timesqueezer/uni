/**
 * Sortiert eine InPlaceSortierbareIntListe mit Bubblesort.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
class BubbleSortierer implements Sortierer
{
    /**
     * Sortiere die angegebene InPlaceSortierbareIntListe aufsteigend in situ.
     * @param liste die zu sortierende Liste
     */
    public void sortiere(InPlaceSortierbareIntListe liste)
    {
        
    }
}
